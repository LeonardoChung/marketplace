function voltar() {
  window.location.href="../inicial_cliente.html"
}

function finalizarCompra() {
  window.location.href = '../pags/compra.html';
}


window.onload = async function() {
  try {
    var resposta = await fetch('../php/obtercarrinho.php');
    var carrinhoItens = await resposta.json();
    console.log("Itens do carrinho:", carrinhoItens);

    var carrinhoHTML = '';

    carrinhoItens.forEach(function (carrinho) {
        carrinhoHTML += `
            <div class="produto">
                <div class="info-produto">
                    <h2>${carrinho.nome}</h2>
                    <p>R$ ${carrinho.valor.toFixed(2)}</p>
                    <button class="botao-remover" onclick="removerProdutoCarrinho('${carrinho.id}')">Remover</button>
                </div>
            </div>
        `;
    });

    var carrinhoContainer = document.getElementById('carrinho-compras');
    carrinhoContainer.innerHTML = carrinhoHTML;


    var total = calcularTotal(carrinhoItens);
    var totalElement = document.createElement('p');
    totalElement.id = 'total';
    totalElement.textContent = `Total: R$ ${total.toFixed(2)}`;
    carrinhoContainer.appendChild(totalElement);

    carrinhoContainer.innerHTML += `
      <button class="botao-finalizar" onclick="finalizarCompra()">Finalizar compra</button>
      <button class="botao-continuar" onclick="voltar()" >Continuar Comprando</button>
    `;

  } catch (erro) {
    console.error("Erro ao obter itens do carrinho:", erro);
  }
}

  
function calcularTotal(carrinhoItens) {
  var total = 0;
  carrinhoItens.forEach(function(carrinho) {
    total += carrinho.valor;
  });
  return total;
}

async function removerProdutoCarrinho(id) {
  try {
    var formData = new FormData();
    formData.append('id', id);

    const response = await fetch("../php/removerDoCarrinho.php", {
      method: "POST",
      body: formData,
    });

    if (response.ok) {
      const resultado = await response.text();
      if (resultado === "Produto removido com sucesso") {
        
        var carrinhoItens = await obterCarrinho();
        atualizarCarrinho(carrinhoItens);
      } else {
        console.error("Erro ao remover o produto:", resultado);
      }
    } else {
      console.error("Erro na solicitação ao servidor");
    }
  } catch (error) {
    console.error("Erro ao remover o produto:", error);
  }
}
