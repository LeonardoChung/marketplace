function voltar() {
    window.location.href="../inicial_cliente.html"
}
function confirmarPagamento() {
    window.location.href="../pags/compraconcluida.html"
}