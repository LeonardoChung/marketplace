function voltar() {
  window.location.href="../inicial_cliente.html"
}