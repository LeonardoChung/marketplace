function expandirDiv(element) {
  element.classList.toggle("expandir");

  var classes = Array.from(document.getElementsByClassName(element.classList[0]));

  var index = classes.indexOf(element);

  for (var i = index + 1; i < classes.length; i++) {
    if (element.classList.contains("expandir")) {
      classes[i].style.top = parseInt(classes[i].style.top) + 450 + "px";
    }
    else {
      classes[i].style.top = parseInt(classes[i].style.top) - 450 + "px";
    }
  }
}


window.onload = async function(){ 
  var resultado = await fetch("php/cards.php",{
      method: "GET"
  });

  var dados = await resultado.json();

  for (var i = 0; i < dados.length; i++) {
      var conteudo =`

      <div class="card-produtos">
        <div class="card-imagem">
          <img src="../imagens/${dados[i].imagem}">
        </div>
        <div class="card-titulo">${dados[i].nome}</div>
        <div class="card-valor">R$ ${dados[i].valor}</div>
        <div class="card-button">
          <button class="botao" onclick="carrinho(${i})">Adicionar ao carrinho</button>
        </div>
      </div>
      `;

    document.getElementById('cards').innerHTML += conteudo;
  }

  function procurar() {
    var input = document.getElementById("buscarProduto");
    var input_value = input.value.toLowerCase();
    var produtos = dados
  
      var produtosfiltrados = produtos.filter(produto => produto.nome.toLowerCase().includes(input_value))
      document.getElementById('cards').innerHTML = ``;
      for(var i = 0; i < produtosfiltrados.length; i++){
      document.getElementById('cards').innerHTML += 
      `
      <div class="card-produtos">
      <div class="card-imagem">
        <img src="imagens/${produtosfiltrados[i].imagem}">
      </div>
      <div class="card-titulo">${produtosfiltrados[i].nome}</div>
      <div class="card-valor">R$ ${produtosfiltrados[i].valor}</div>
      <div class="card-button">
        <button class="botao" onclick="carrinho(${i})">Adicionar ao carrinho</button>
      </div>
    </div>`;
    }
  }
  var input = document.getElementById("buscarProduto");
  input.addEventListener('input', procurar)
}



function carrinho(index) {
  var dados = document.getElementsByClassName('card-produtos')[index];
  var nome = dados.getElementsByClassName('card-titulo')[0].innerText;
  
  var valorTexto = dados.getElementsByClassName('card-valor')[0].innerText;
  var valorNumerico = parseFloat(valorTexto.replace('R$', '').trim());

  fetch('php/adicionaraocarrinho.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: `nome=${nome}&valor=${valorNumerico}`
  });
}
