function voltar() {
    window.location.href="../inicial_adm.html"
  }