

function voltar() {
  window.location.href="../inicial_adm.html"
}


async function Gravar(){
  var arquivo = document.getElementById("arquivo").files;
  var form = document.getElementById("formulario");
  var dados = new FormData(form);
  dados.append('arquivo', arquivo[0]);

  await fetch('../php/gravar_item.php', {
    method: "POST",
    body: dados
  });
}

