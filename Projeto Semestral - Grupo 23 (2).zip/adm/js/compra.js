window.onload = async function() {
    try {
        var resposta = await fetch('../php/obtercarrinho.php');
        var carrinhoItens = await resposta.json();
        console.log("Itens do carrinho:", carrinhoItens);

        var carrinhoContainer = document.querySelector('.container');
        carrinhoItens.forEach(function(produto) {
            var item = document.createElement('div');
            item.className = 'produto';
            item.innerHTML = `
                <div class="produto-nome">${produto.nome}</div>
                <div class="produto-preco">R$ ${produto.valor.toFixed(2)}</div>
            `;
            carrinhoContainer.appendChild(item);
        });

        var totalElement = document.createElement('div');
        totalElement.className = 'total';
        var total = calcularTotal(carrinhoItens);
        totalElement.textContent = `Total: R$ ${total.toFixed(2)}`;
        carrinhoContainer.appendChild(totalElement);

        var formaPagamentoElement = document.createElement('div');
        formaPagamentoElement.className = 'forma-pagamento';
        formaPagamentoElement.innerHTML = `
            <h2>Forma de Pagamento</h2>
            <div class="form-group">
                <select id="pagamento" name="pagamento" required>
                    <option value="credito">Cartão de Crédito</option>
                    <option value="debito">Cartão de Débito</option>
                    <option value="pix">Pix</option>
                </select>
            </div>
            <input type="submit" class="confirmar-compra" value="Confirmar Compra" onclick="confirmarCompra()">

        `;
        carrinhoContainer.appendChild(formaPagamentoElement);

    } catch (erro) {
        console.error("Erro ao obter itens do carrinho:", erro);
    }

}

function calcularTotal(carrinhoItens) {
    var total = 0;
    carrinhoItens.forEach(function(produto) {
        total += produto.valor;
    });
    return total;
}

function confirmarCompra() {
    var pagamentoSelecionado = document.getElementById('pagamento').value;

    if (pagamentoSelecionado === 'pix') {
        window.location.href = '../pags/pix.html';
    } else {
        console.log('Processando pagamento via', pagamentoSelecionado);
    }

    if (pagamentoSelecionado === 'credito' || pagamentoSelecionado === 'debito') {
        window.location.href = '../pags/cartao.html';
    } else {
        console.log('Processando pagamento via', pagamentoSelecionado);
    }
}

function voltar() {
    window.location.href="../index.html"
}
