function voltar() {
    window.location.href="../inicial_adm.html"
}


function confirmarPagamento() {
    window.location.href="../pags/compraconcluida.html"
}