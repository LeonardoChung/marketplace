<?php
  
  $nome = $_POST['nome'];
  $valor = floatval($_POST['valor']);

  $conexao = mysqli_connect("localhost", "root", "minwoo280305", "clicktech");

  $query = "INSERT INTO carrinho (nome, valor) VALUES ('$nome', '$valor')";
  mysqli_query($conexao, $query);
  mysqli_close($conexao);
?>
