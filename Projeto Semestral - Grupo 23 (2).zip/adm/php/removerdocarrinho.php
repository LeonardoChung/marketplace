<?php
    $id = $_POST['id'];

    $conexao = mysqli_connect("localhost", "root", "minwoo280305", "clicktech");


    $query = "DELETE FROM carrinho WHERE id = '$id'";
    $result = mysqli_query($conexao, $query);



    mysqli_close($conexao);
?>