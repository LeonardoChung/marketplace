<?php

  $id = $_GET['id']; 

  $conexao = mysqli_connect("localhost", "root", "minwoo280305", "clicktech");

  $query = "DELETE FROM produto WHERE id_produto = $id";

  if (mysqli_query($conexao, $query)){
    echo "Apagado com sucesso!";
  }
  else{
    echo "Erro ao apagar o produto!";
  }

?>
