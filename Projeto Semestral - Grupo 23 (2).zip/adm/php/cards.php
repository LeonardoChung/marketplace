<?php 

  $conexao = mysqli_connect("localhost", "root", "minwoo280305", "clicktech");

  $resultado = mysqli_query($conexao, "SELECT * FROM produto");

  $dados = array();

  while($registro = mysqli_fetch_assoc($resultado)){

    array_push($dados, $registro);
  }

  $json = json_encode($dados);
  echo $json;

?>
