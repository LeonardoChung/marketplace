<?php

  $arquivo = $_FILES["arquivo"];

  if($arquivo["type"] == 'image/jpeg' ||$arquivo["type"] == 'image/jpg' || $arquivo["type"] == 'image/png') {
    $novo_endereco = "../../imagens/".$arquivo["name"];
  }
  
  move_uploaded_file($arquivo["tmp_name"], $novo_endereco);

  $imagem = $arquivo["name"];
  $nome = $_POST['nome'];
  $preco = $_POST['preco'];

  $conexao = mysqli_connect("localhost", "root", "minwoo280305", "clicktech");

  $query = "INSERT INTO produto (imagem, nome, valor) VALUES ('$imagem', '$nome', '$preco')";
  
  mysqli_query($conexao, $query);

?>