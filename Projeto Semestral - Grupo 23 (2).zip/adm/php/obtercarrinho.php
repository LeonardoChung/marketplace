<?php
    $conexao = mysqli_connect("localhost", "root", "minwoo280305", "clicktech");

    $query = "SELECT * FROM carrinho";
    $resultado = mysqli_query($conexao, $query);

    $carrinhoItens = array();

    while ($row = mysqli_fetch_assoc($resultado)) {

        $item = array(
            "id" => $row['id'],
            "nome" => $row['nome'],
            "valor" => floatval($row['valor']),
        );
        array_push($carrinhoItens, $item);
    }

    header('Content-Type: application/json');
    echo json_encode($carrinhoItens);

    mysqli_close($conexao);
?>