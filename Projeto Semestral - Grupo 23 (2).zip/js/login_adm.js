async function Login() {
  var form = document.getElementById("formulario");
  var dados = new FormData(form);

  const response = await fetch("php/login_adm.php", {
    method: "POST",
    body: dados,
  });

  if (response.ok) {
    const resultado = await response.text();
    if (resultado === "Login bem-sucedido!") {
      window.location.href = "adm/inicial_adm.html";
    }
  } 
  else {
    alert("Erro na solicitação ao servidor");
  }
} 