async function Cadastrar() {
  var form = document.getElementById("formulario");
  var dados = new FormData(form);
  
  await fetch("php/cadastro_cliente.php", {
    method: "POST",
    body: dados
  });
}

