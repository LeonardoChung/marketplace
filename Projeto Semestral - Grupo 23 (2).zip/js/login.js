async function Login() {
  var form = document.getElementById("formulario");
  var dados = new FormData(form);

  const response = await fetch("php/login.php", {
    method: "POST",
    body: dados,
  });

  if (response.ok) {
    const resultado = await response.text();

    if (resultado === "Login bem-sucedido!") {
      window.location.href = "cliente/inicial_cliente.html";
    }
  } 
  else {
    alert("Erro na solicitação ao servidor");
  }
}