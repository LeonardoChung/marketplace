<?php

  $email = $_POST['email'];
  $senha = $_POST['senha'];

  $conexao = mysqli_connect("localhost", "root", "minwoo280305", "clicktech");

  $query = "INSERT INTO clientes (email, senha) VALUES ('$email', '$senha')";

  mysqli_query($conexao, $query);

?>