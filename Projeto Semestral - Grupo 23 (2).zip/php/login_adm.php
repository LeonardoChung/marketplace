<?php


$email = $_POST['email'];
$senha = $_POST['senha'];


$conexao = mysqli_connect("localhost", "root", "minwoo280305", "clicktech");



$query = "SELECT email, senha FROM administradores WHERE email = '$email' AND senha = '$senha'";
$resultado = mysqli_query($conexao, $query);

if (mysqli_num_rows($resultado) == 1) {
    echo "Login bem-sucedido!";
} else {
    echo "Login falhou. Verifique suas credenciais.";
}

mysqli_close($conexao);

?>